class ParserJSON
  def initialize
    @pilha = []
  end

  def empilhar(caractere)
    @pilha.push(caractere)
  end

  def desempilhar
    @pilha.pop
  end

  def parse(json_string)
    estado = :inicio
    token_atual = ''

    json_string.each_char do |caractere|
      case [caractere, estado]
      when ['{', :inicio]
        empilhar('{')
        estado = :dentro_objeto
      when ['}', :dentro_objeto]
        desempilhar
        estado = :apos_objeto
      when ['[', :inicio]
        empilhar('[')
        estado = :dentro_array
      when [']', :dentro_array]
        desempilhar
        estado = :apos_array
      when ['"', :inicio], ["'", :inicio]
        estado = :dentro_string
        token_atual += caractere
      when ['"', :dentro_string], ["'", :dentro_string]
        estado = :inicio
        token_atual += caractere
        puts "String: #{token_atual}" 
        token_atual = ''
      when [':', :dentro_objeto]
        estado = :apos_dois_pontos
      when [',', :apos_dois_pontos], [',', :apos_array]
        estado = :inicio
      when ['t', :inicio]
        estado = :verdadeiro
      when ['r', :verdadeiro]
        estado = :verdadeiro
      when ['u', :verdadeiro]
        estado = :verdadeiro
      when ['e', :verdadeiro]
        puts "Booleano: true"
        estado = :inicio
      when ['f', :inicio]
        estado = :falso
      when ['a', :falso]
        estado = :falso
      when ['l', :falso]
        estado = :falso
      when ['s', :falso]
        estado = :falso
      when ['e', :falso]
        puts "Booleano: false"
        estado = :inicio
      when ['n', :inicio]
        estado = :nulo
      when ['u', :nulo]
        estado = :nulo
      when ['l', :nulo]
        estado = :nulo
      when ['l', :nulo]
        puts "Nulo"
        estado = :inicio
      else
        token_atual += caractere
      end
    end

    if @pilha.empty? && estado == :inicio
      puts "JSON válido"
    else
      puts "Erro: JSON inválido"
    end
  end
end

# Exemplo de uso:
parser_json = ParserJSON.new
parser_json.parse('{"nome": "João", "idade": 30, "Estudante": true, "amigos": ["Alice", "Bob"], "endereço": {"cidade": "Nova York", "cep": 12345}, "valorNulo": null}')
